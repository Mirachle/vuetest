<template>
  <div>
    <img class="acmeImg" src="@/components/acme.png" alt="acme">
  </div>
</template>

<script>

export default {
  name: 'SignUpImg',

};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.acmeImg{
    padding: auto;
    margin: auto;
    margin-left:0px;
}

</style>
