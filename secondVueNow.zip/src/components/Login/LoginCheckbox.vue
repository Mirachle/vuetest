<template>
  <div class="row">
    <h5><span @click="boxClicked()" :class="circle" />{{text}}</h5>
  </div>
</template>

<script>

export default {
  name: 'LoginCheckbox',
  data() {
    return {
     text: "Remember me.",
     circle: "span-blue",
    };
  },

  methods: {
    boxClicked() {
      this.circle = this.circle === "span-blue" ? "span-white" : "span-blue";
    },
  }
};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

h5 {
    color: #a1a1a1;
    font-size: 1.3vw;
}

.span-blue{
width: 14px;
border-radius: 50%;
border:2px solid #4a90e2;
height: 14px;
margin-right: 0.5vw;
margin-left: 1.3vw;
display: inline-block;
background-color: #4a90e2;
}

.span-white{
width: 14px;
border-radius: 50%;
border:2px solid #4a90e2;
height: 14px;
margin-right: 0.5vw;
margin-left: 1.3vw;
display: inline-block;
background-color: white;
}

</style>
