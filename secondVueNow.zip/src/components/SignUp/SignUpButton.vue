<template>
  <div>
    <input type="button" class="sign-up-btn btn" value="Log in">
  </div>
</template>

<script>

export default {
  name: 'SignUpButton',
  data() {
    return {

    };
  },
};

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.sign-up-btn{
    margin-right: auto;
    margin-top: 1vw;
    text-align: center;
    padding-left: 2vw;
    padding-right: 2vw;
    padding-top: 0.5vw;
    padding-bottom:0.5vw;
    color: #ffffff;
    border-color: #ffffff;
    border-radius: 5%;
    border-width: 2px;
    background-color: transparent;
}


</style>
